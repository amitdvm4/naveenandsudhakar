function fnSearch(){
    var hnoRef=document.querySelector('#hno');

    var hno=hnoRef.value ;

    if(hno == ''){
        alert('please enter hno');
        return;
    }

    if(hno.length != 24){
        alert('hno should be 24 chars');
        return ;
    }

    sendReq(
        'get',
        'http://localhost:2020/marks/get-std-det?hno='+hno,
        undefined,
        function(res){
            debugger;
            if(res == ''){
                alert('please enter valid hno');
            }else{
                res=JSON.parse(res);
                document.querySelector('#content').classList.remove('disp-none');
                document.querySelector('#disp-name').innerText=res.name;
                document.querySelector('#disp-phone').innerText=res.phone;

            }
        },
        function(res){
            debugger;
        }
    )

}


function fnSubmit(){
    var engRef=document.getElementById('eng');
    var sceRef=document.getElementById('sce');
    var csRef=document.getElementById('cs');

    var eng=engRef.value;
    var sce=sceRef.value;
    var cs=csRef.value;

    if(eng == ''){
        alert('pelase enter eng marks');
        return;
    }
    if(isNaN(eng)){
        alert('please enter numebr only');
        return;
    }

    if(eng < 0 || eng >25){
        alert('marks in between 0-25');
        return;
    }


    if(sce == ''){
        alert('pelase enter science marks');
        return;
    }
    if(isNaN(sce)){
        alert('please enter numebr only');
        return;
    }

    if(sce < 0 || sce >25){
        alert('marks in between 0-25');
        return;
    }


    if(cs == ''){
        alert('pelase enter cs marks');
        return;
    }
    if(isNaN(cs)){
        alert('please enter numebr only');
        return;
    }

    if(cs < 0 || cs >25){
        alert('marks in between 0-25');
        return;
    }


    var dataObj={
        'hno':document.querySelector('#hno').value,
        'name':document.getElementById('disp-name').innerText,
        'eng':eng,
        'sce':sce,
        'cs':cs
    }

    sendReq(
        'post',
        'http://localhost:2020/marks/insert-marks',
        dataObj,
        function(res){
            debugger;
            var res = JSON.parse(res);
            if (res.insertedCount == 1 && res.ok == 1) {
                alert('markes insered');
                document.querySelector('#content').classList.add('disp-none');
                document.querySelector('#hno').value='';
            } else {

               alert('not insert...try again');
            }
        },
        function(res){
            debugger;
        }
    )



}