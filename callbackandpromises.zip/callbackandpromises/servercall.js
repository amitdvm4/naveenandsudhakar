function sendReq(url,m,scb,ecb){
	var o=new XMLHttpRequest();
		o.open(m,url,true);
		o.send();
		o.onload=function(){
			debugger;
			scb(o.responseText);
		}
		o.onerror=function(){
			debugger;
			ecb('somethig went wrong');
		}
}

function sendReqPromise(u,m){
	return new Promise(function(resolve,reject){
        var o=new XMLHttpRequest();
		o.open(m,u,true);
		o.send();
		o.onload=function(){
			debugger;
			resolve(o.responseText);
		}
		o.onerror=function(){
			debugger;
			reject('somethig went wrong');
		}
	});
}